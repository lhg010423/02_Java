package gwajae.stock.run;

import gwajae.stock.view.StockView;

public class StockRun {
	public static void main(String[] args) {
		
		System.out.println("==========프로그램 실행==========");
		
		StockView view = new StockView();
		
		view.startView();
		
		
	}
}
